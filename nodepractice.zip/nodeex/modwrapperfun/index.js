(function(exports,require,module,__filename,__dirname){
    const a= require("fs")
    const name="vinod";
    console.log(name);
    module.exports={dkl}
})
