const http=require("http");
const fs=require("fs")
const server=http.createServer();
server.on("require",(req,res)=>{
    //3rd way
    const rstream=fs.createReadStream("file.txt");
    rstream.pipe(res);



});
server.listen(8258,()=>{console.log("Iam done")})