const http=require("http");
const fs=require("fs");
const server= http.createServer();
server.on("request",function(req,res){
    var fs=require("fs");
    fs.readFile("file.txt",function(err,data){
        if(err) return console.error(err);
        res.end(data.toString());
    });
    
});
server.listen(8088,()=>{console.log("file is readed sucessfully")})