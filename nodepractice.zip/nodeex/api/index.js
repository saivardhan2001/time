const fs=require('fs')
const http=require('http')
http.createServer(function(req,res){
    //we have to use an object in json format
    const data=fs.readFileSync('using.js','utf-8')//(`${__dirname}/api/api.json`,'utf-8')
    //const objdata=JSON.parse(data)
    //console.log(req.url)
    if(req.url=='/'){
        res.end("Hello welcome to my website")
    }else if(req.url=='/about'){
        res.end(data)
        
    }else{res.end("sorry we do not have product")}
    
}).listen(8080,function(){console.log("server is running")})