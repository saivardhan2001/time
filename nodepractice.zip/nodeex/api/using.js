//API(application programming interfaceing)
// API allows softwares to communicate with each other
//API is a service which allow us to request data
const  biodata={
    Name:"sai vardhan",
    Age:21,
    Collage:"IARE"
}