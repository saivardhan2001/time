//1)convert the object into JSON
//2)add the data into another file
//3)read the file
//4)convert back to object
//5)print the object

//create object

const task={
    Name:"about json",
    Place:"Hyderabad",
    id:44456
}
//1)convert it into JSON
 const jsondata=JSON.stringify(task)
//2)use write function in FS to add the data into another file
const fs=require('fs')
fs.writeFile("task1.json",jsondata,function(err){
    console.log("File written sucessfully..")
})
//3)read the file by using readfile
fs.readFile('task1.json', 'utf-8',function(err,data){
    console.log("This is JSON data"+data)
 //4)convert JSON ito object   
    const orgdata=JSON.parse(data)
//5)print the object
    console.log(orgdata)
})
