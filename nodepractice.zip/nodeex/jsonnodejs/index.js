// Json stands for javascript object notation.
// Json is lightweight
// Format for storing and transporting data
// Json is often used when data is sent from a server to a web page
const  biodata={
    Name:"sai vardhan",
    Age:21,
    Collage:"IARE"
}
//TO convert the object into JSON
const jsondata=JSON.stringify(biodata)
console.log(jsondata)
//TO convert the JSON into object
const objdata=JSON.parse(jsondata)
console.log(objdata)

