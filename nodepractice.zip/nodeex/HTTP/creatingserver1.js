var http=require('http')
http.createServer(function(req,res){
    res.end("<h1>hello welcome to my page...</h1>")
}).listen(8086,function(){console.log("hello iam running....")})