//creating server in node
//http is a inbuild module in node we no need to download any third party modules
//.listen is used to define portnumber init.

var http=require('http')
var hello="hello"
http.createServer((req,res)=>{
    console.log(req.url)
     if (req.url=='/'){
         res.end("welcome to home page")
     }else if(res.url=='/about'){
         res.end(hello)
     }else if(req.url=='/cat'){
         res.end("this is catagory in your site")
     }else{
        res.writeHead(404,{"content-type":"text/html"})
        res.end("<h1>404 error page contact us</h1>")}
}).listen(8086,()=>{console.log("<h1>helll iam listening</h1>")})
 