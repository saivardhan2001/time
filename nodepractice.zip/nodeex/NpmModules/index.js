const chalk=require('chalk')

console.log(chalk.blue('Hello world!'));
s

