var fs=require('fs')
fs.unlink('hello.js',function(err){
    console.log("deleted")
})