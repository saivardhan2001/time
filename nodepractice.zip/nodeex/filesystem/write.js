var fs=require('fs')
fs.writeFile('dummydata.js','console.log("hello we are writing data plese wait")',function(err){
    console.log("data is written sucessfully")
})