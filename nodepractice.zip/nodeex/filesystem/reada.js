var fs=require('fs')
fs.readFile('employees.csv','utf8',function(err,data){
    console.log( data)
})