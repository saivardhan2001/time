var fs=require('fs')
fs.renameSync('read.js','reada.js')