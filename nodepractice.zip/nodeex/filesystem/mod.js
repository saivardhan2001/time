var fs=require('fs')
fs.writeFile('hello.js','console.log("welcome to new world let us come together")',function(err){
    console.log("helo welcome again")
})