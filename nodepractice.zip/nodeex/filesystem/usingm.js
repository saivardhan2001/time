


var char=require('./creatingm.js')
result=char.add(2,3)
console.log("hello"+result)
