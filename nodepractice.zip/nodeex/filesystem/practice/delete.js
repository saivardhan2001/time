var fs=require('fs')
fs.unlink('deleting.js',function(err){
    console.log("deleted sucessfully")
})//console.log("iam adding the data")