var fs=require('fs')
fs.appendFileSync('delete.js','//console.log("iam adding the data")') 