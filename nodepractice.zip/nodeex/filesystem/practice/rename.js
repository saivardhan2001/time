var fs=require('fs')
fs.renameSync('file.js','create.js')