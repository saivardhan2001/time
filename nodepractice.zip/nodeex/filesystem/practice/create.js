var fs=require('fs')
fs.writeFile('read.js','console.log("hello world we are writing a file from another file")',function(err){
    console.log("file is written sucessfull, thank you ")
})