//create an event emitter instance and register a couple of instances
const EventEmitter=require("events");
const event=new EventEmitter();
event.on("say my name",()=>{
    console.log("hello my name is k sai vardhan reddy");
});
event.emit("say my name")
event.on("register",()=>{
    console.log("sucessfully registered");
});
event.emit("register")