//We can fetch the operating system version by using os modules
const os=require('os')
console.log(os.arch())
//host name
console.log(os.hostname())
//to get platform
console.log(os.platform())
//to get total memory
const freeMemory=os.totalmem()
console.log(freeMemory)
//to get free memory, we can use 
const totalmemory=os.totalmem()
console.log(totalmemory)

