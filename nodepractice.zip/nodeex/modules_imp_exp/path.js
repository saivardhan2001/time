const path=require('path')
console.log(path.dirname('C:/Users/saiva/nodeex/usingmodules/path.js'))
console.log(path.extname('C:/Users/saiva/nodeex/usingmodules/path.js'))
console.log(path.basename('C:/Users/saiva/nodeex/usingmodules/path.js'))
//we can use parse to know all the path details such as root,dir,base,ext,name. it saves the time.
console.log(path.parse('C:/Users/saiva/nodeex/usingmodules/path.js'))
//we can also extract specific details about name,root etc by defining the variable to it.
const mypath=path.parse('C:/Users/saiva/nodeex/usingmodules/path.js')
console.log(mypath.name) 
