function add(a,b) {
    return a+b;
}
const sub=(a,b) =>{
    return a-b;
}
function mult(a,b){
    return a*b;
}
function divi(a,b){
    return a/b;
}
function mod(a,b){
    return a%b;
}
//  module.exports.add=add;
//  module.exports.sub=sub;
// insted of writing add,sub seperatly we can define in one linesuch as
//module.exports={add,sub,mult,divi,mod}
console.log(add(2,3))
console.log(sub(10,3))
console.log(mult(2,8))
console.log(divi(7,3))
console.log(mod(2,8))


