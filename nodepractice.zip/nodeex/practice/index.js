const EventEmitter=require("events");
const event=new EventEmitter();
event.on("say my name",function(){
    console.log("my name is k sai vardhan reddy")
});
event.emit("say my name");